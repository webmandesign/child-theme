<?php

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

/**
 * Use this file for your custom PHP functionality.
 *
 * Your custom PHP functionality:
 */
